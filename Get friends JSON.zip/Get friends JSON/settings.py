api_v = '5.95'
token = 'c77a605bf17f1ed122b9dbc250da65953d1cfd44e38c154fdbac05b0a4cd94932c93f3b922c3b904701a8'
my_id = '134448659'
max_workers = 2
delay = 0.5
deep = 1